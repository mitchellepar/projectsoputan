package com.example.gunungsoputan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView buku_tamu = findViewById(R.id.tombolbuku);
        ImageView informasi = findViewById(R.id.tombolinformasi);
        ImageView jalur = findViewById(R.id.tomboljalur);
        ImageView darurat = findViewById(R.id.tomboldarurat);

        buku_tamu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, scanbarcodetamu.class);
                startActivity(intent);
            }
        });

       informasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, informasigunung.class);
                startActivity(intent);
            }
        });

        jalur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, jalurpendakian.class);
                startActivity(intent);
            }
        });

        darurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomor="081244477260";
                Intent memangil = new Intent(Intent.ACTION_DIAL);
                memangil.setData(Uri.fromParts("tel",nomor, null));
                startActivity(memangil);
            }
        });
    }









}